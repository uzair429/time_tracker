import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:work_time_tracker/controller/add_shift_controller.dart';
import 'package:work_time_tracker/controller/start_shift_controller.dart';
import 'package:work_time_tracker/screens/add_shift_screen.dart';
import 'package:work_time_tracker/screens/shift_detail_screen.dart';
import 'package:work_time_tracker/screens/start_shift_screen.dart';
import 'package:work_time_tracker/user_guide_screens/main_screen_guide.dart';

void main() {
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider<AddShiftController>(
        create: (_) => AddShiftController(),
      ),
      ChangeNotifierProvider<StartShiftController>(
        create: (_) => StartShiftController(),
      ),
    ],
    child: const MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        // useMaterial3: true,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  late final StartShiftController provider;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    provider = Provider.of<StartShiftController>(context, listen: false);
    initialize();
  }

  void initialize() async {
    await provider.isShiftRun();
  }
  @override
  Widget build(BuildContext context) {
    final provider2 = Provider.of<StartShiftController>(context);
    // provider.isShiftRun();
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: const Center(child: Text('Work Time Tracker')),
        actions: [
          IconButton(
              onPressed: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context){
                  return MainScreenGuide();
                }));
              },
              icon: const Icon(Icons.announcement_rounded)),

        ],
      ),
      body: Container(
        width: width,
        height: height,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                onPressed: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) {
                    return AddShiftScreen();
                  }));
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 65.0),
                  child: Text(
                    'ADD SHIFT',
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                )),
            ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                onPressed: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) {
                    return StartShiftScreen();
                  }));
                },
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: provider2.isShiftRunning ? 6 : 0, horizontal: provider2.isShiftRunning ? 5 : 50.0),
                  child: Text(
                    'PUNCH SHIFT ${provider2.isShiftRunning ? '(Running)': ''}',
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                )),
            ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                onPressed: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) {
                    return ShiftDetailScreen();
                  }));
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 50.0),
                  child: Text(
                    'SHIFT DETAIL ',
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
