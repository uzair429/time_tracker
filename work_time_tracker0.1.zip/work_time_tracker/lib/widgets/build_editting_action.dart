import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:work_time_tracker/controller/add_shift_controller.dart';

class BuildEditingAction extends StatelessWidget {
  const BuildEditingAction({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      onPressed: () {
        final provider =
        Provider.of<AddShiftController>(context, listen: false);
        final Duration spent = provider.toDate.difference(provider.fromDate);
        provider.addShiftEntry(
          context: context,
            startTime: provider.fromDate,
            endTime: provider.toDate,
            timeSpent: spent,
          note: provider.note,
        );
      },
      icon: const Icon(
        Icons.done,
      ),
      label: Text('Save'),
    );
  }
}
