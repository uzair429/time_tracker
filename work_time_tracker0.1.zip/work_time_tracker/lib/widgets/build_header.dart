import 'package:flutter/material.dart';

class BuildHeader extends StatelessWidget {
  final header;
  final child;
  const BuildHeader({Key? key,required this.header, required this.child}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              header,
              style: TextStyle(fontWeight: FontWeight.normal, fontSize: 22),
            ),
            child
          ],
        ),
      ),
    );
  }
}
