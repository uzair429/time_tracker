import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:work_time_tracker/controller/start_shift_controller.dart';
import '../utils/utils.dart';
import '../widgets/build_drop_down_field.dart';
import '../widgets/build_header.dart';
import '../widgets/build_note.dart';

class StartShiftScreen extends StatefulWidget {
  const StartShiftScreen({Key? key}) : super(key: key);

  @override
  State<StartShiftScreen> createState() => _StartShiftScreenState();
}

class _StartShiftScreenState extends State<StartShiftScreen> {
  late final StartShiftController provider;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    provider = Provider.of<StartShiftController>(context, listen: false);
    initialize();
  }

  void initialize() async {
    await provider.isShiftRun();
    await provider.getTotalBreak();
    if(!provider.isShiftRunning){
      provider.startShift();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.purple[50],
      appBar: AppBar(
        actions: [
          CloseButton(
            onPressed: () {
            //   showDialog(context: context, builder:(context){
            //     return AlertDialog(
            //       title: Text('Are You Sure to Remove Timer'),
            //       actions: [
            //         ElevatedButton(
            //             onPressed: () => Navigator.of(context).pop()
            //             , child : Text('CANCEL')),
            //         ElevatedButton(
            //             onPressed: (){
            //               provider.disposeShift();
            //               Navigator.of(context).pop();
            //             },
            //             child : Text('REMOVE')),
            //       ],
            //     );
            //   });
              provider.disposeShift();
              Navigator.of(context).pop();
            },
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              BuildStartFrom(),
              BreakButton(),
              TotalDuration(),
              BuildNote(controller: provider.startShiftNoteController,),
              BuildPunchOutButton()
            ],
          ),
        ),
      ),
    );
  }
}


class TotalDuration extends StatelessWidget {
  const TotalDuration({Key? key}) : super(key: key);

  String _formatDuration(Duration duration) {
    return '${duration.inHours}h ${duration.inMinutes.remainder(60)}m';
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<StartShiftController>(context);
    return  BuildHeader(
        header: "Total Duration",
        child: SizedBox(
          width: MediaQuery.of(context).size.width,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(_formatDuration(provider.totalBreakDuration)),
            ))
    );
  }
}

class BreakButton extends StatelessWidget {
  const BreakButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<StartShiftController>(context);
    return  BuildHeader(
      header: "Add Break",
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: provider.breakController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Add Break in (minutes)'
              ),
            ),
          ),
          TextButton(onPressed: (){
            provider.addBreak();
          }, child: Text('ADD'))
        ],
      )
    );
  }
}


class BuildPunchOutButton extends StatelessWidget {
  const BuildPunchOutButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
        onPressed: (){
          final provider = Provider.of<StartShiftController>(context, listen: false);
          final endTime = DateTime.now();
          Duration spent = endTime.difference(provider.startDate);
          spent = spent - provider.totalBreakDuration;
          print('this is the start date ${provider.startDate}');
          provider.addShiftEntry2(
            context: context,
            startTime: provider.startDate,
            endTime: endTime,
            timeSpent: spent,
            note: provider.startShiftNoteController,
          );
        },
        child: Text('PUNCH OUT'));
  }
}




class BuildStartFrom extends StatelessWidget {
  const BuildStartFrom({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<StartShiftController>(context);
    return BuildHeader(
      header: "Starting Date and Time",
      child: Row(
        children: [
          Text(Utils.toDate(provider.startDate)),
          // Expanded(
          //     flex: 2,
          //     child: BuildDropDownField(
          //       text: Utils.toDate(provider.startDate),
          //       onClicked: () {
          //         provider.pickStartDateTime(context: context, pickDate: true);
          //       },
          //     )),
          Expanded(
              child: BuildDropDownField(
            text: Utils.toTime(provider.startDate),
            onClicked: () {
              provider.pickStartDateTime(context: context, pickDate: false);
            },
          )),
        ],
      ),
    );
  }
}
