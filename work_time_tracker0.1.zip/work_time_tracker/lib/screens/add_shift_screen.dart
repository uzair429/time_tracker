import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:work_time_tracker/controller/add_shift_controller.dart';
import 'package:work_time_tracker/widgets/build_from.dart';
import 'package:work_time_tracker/widgets/build_note.dart';
import 'package:work_time_tracker/widgets/build_to.dart';
import '../widgets/build_editting_action.dart';

class AddShiftScreen extends StatefulWidget {
  const AddShiftScreen({Key? key}) : super(key: key);

  @override
  State<AddShiftScreen> createState() => _AddShiftScreenState();
}

class _AddShiftScreenState extends State<AddShiftScreen> {
  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AddShiftController>(context, listen: false);
    return Scaffold(
      backgroundColor: Colors.purple[50],
      appBar: AppBar(
        leading: CloseButton(),
        actions:[BuildEditingAction()],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              BuildFrom(),
              BuildTo(),
              BuildNote(controller:provider.note)
            ],
          ),
        ),
      ),
    );
  }
}