import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:work_time_tracker/controller/add_shift_controller.dart';
import 'package:work_time_tracker/helper/shift_data_source.dart';

import '../models/shift_model.dart';

class ShiftDetailScreen extends StatefulWidget {
  const ShiftDetailScreen({Key? key}) : super(key: key);

  @override
  State<ShiftDetailScreen> createState() => _ShiftDetailScreenState();
}

class _ShiftDetailScreenState extends State<ShiftDetailScreen> {


  List<ShiftModel> shifts = <ShiftModel>[];
  ShiftDataSource? shiftDataSource;
  late final AddShiftController provider;
  @override
  void initState() {
    super.initState();
    provider = Provider.of<AddShiftController>(context, listen: false);
    initialize();
    // provider.loadAllTimeEntries();
    // setState(() {
    //   shifts = provider.allShiftEntries;
    // });
    // shiftDataSource = ShiftDataSource(shiftData: shifts);
  }

  initialize() async {
    await provider.loadAllTimeEntries();
    setState(() {
      shifts = provider.allShiftEntries;
    });
    shiftDataSource = ShiftDataSource(shiftData: shifts);
  }

  @override
  Widget build(BuildContext context) {
    // final provider = Provider.of<AddShiftController>(context, listen: false);
   // print(provider.allShiftEntries);
    return Scaffold(
      appBar: AppBar(
        title: Text('Shift Detail'),
      ),
      body : Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    shifts = provider.allShiftEntries;
                  });
                  shiftDataSource = ShiftDataSource(shiftData: shifts);
                  print('All button pressed');
                },
                child: Text('All'),
              ),
              ElevatedButton(
                onPressed: () {
                  // final selectedDate = DateTime.now();
                  final selectedDate = DateTime.now();

                  List<ShiftModel> shiftsInSelectedWeek = provider.allShiftEntries.where((shift) {
                    DateTime getDate(DateTime d) => DateTime(d.year, d.month, d.day);

                    // Check if the shift falls within the selected week
                    return shift.startTime.isAfter(getDate(selectedDate.subtract(Duration(days: selectedDate.weekday - 1)))) &&
                        shift.startTime.isBefore(getDate(selectedDate.add(Duration(days: DateTime.daysPerWeek - selectedDate.weekday))));
                  }).toList();

                  setState(() {
                    shifts = shiftsInSelectedWeek;
                  });
                  shiftDataSource = ShiftDataSource(shiftData: shifts);
                  print('Week button pressed');
                },
                child: Text('Week'),
              ),
              ElevatedButton(
                onPressed: () {
                  DateTime selectedMonth = DateTime.now();
                  // Filter shifts for the selected month
                  List<ShiftModel> shiftsInSelectedMonth = provider.allShiftEntries.where((shift) {
                    return shift.startTime.year == selectedMonth.year &&
                        shift.startTime.month == selectedMonth.month;
                  }).toList();

                  setState(() {
                    shifts = shiftsInSelectedMonth;
                  });
                  shiftDataSource = ShiftDataSource(shiftData: shifts);
                  // Handle "Month" button press
                  print('Month button pressed');
                },
                child: Text('Month'),
              ),
              ElevatedButton(
                onPressed: () {
                  DateTime selectedYear = DateTime.now();
                  List<ShiftModel> shiftsInSelectedYear = provider.allShiftEntries.where((shift) {
                    return shift.startTime.year == selectedYear.year;
                  }).toList();
                  setState(() {
                    shifts = shiftsInSelectedYear;
                  });
                  shiftDataSource = ShiftDataSource(shiftData: shifts);
                  print('Year button pressed');
                },
                child: Text('Year'),
              ),
            ],
          ),
          shiftDataSource == null
              ? const Center(child: CircularProgressIndicator()) :
          Expanded(
            child: SfDataGrid(
              gridLinesVisibility: GridLinesVisibility.both,
              source: shiftDataSource!,
              columnWidthMode: ColumnWidthMode.fill,
              columns: <GridColumn>[
                GridColumn(
                    columnName: 'date',
                    label: Container(
                        padding: EdgeInsets.all(16.0),
                        alignment: Alignment.center,
                        child: Text(
                          'Date',
                        ))),
                GridColumn(
                    columnName: 'hours',
                    label: Container(
                        padding: EdgeInsets.all(8.0),
                        alignment: Alignment.center,
                        child: Text('Hours'))),
                GridColumn(
                    columnName: 'note',
                    label: Container(
                        padding: EdgeInsets.all(8.0),
                        alignment: Alignment.center,
                        child: Text(
                          'Note',
                          overflow: TextOverflow.ellipsis,
                        ))),
              ],
              onQueryRowHeight: (details) {
                return details.getIntrinsicRowHeight(details.rowIndex);
              },
              tableSummaryRows: [
                GridTableSummaryRow(
                    title: 'Sum of Duration : {hours} ',
                    showSummaryInRow: true,
                    columns: [
                      GridSummaryColumn(
                        name: 'hours',
                        columnName: 'hours',
                        summaryType: GridSummaryType.sum,
                      ),
                    ],
                    position: GridTableSummaryRowPosition.bottom)
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ButtonRow extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        ElevatedButton(
          onPressed: () {

            print('All button pressed');
          },
          child: Text('All'),
        ),
        ElevatedButton(
          onPressed: () {

            // List<ShiftModel> shiftsInSelectedWeek = shiftList.where((shift) {
            //   // Check if the shift falls within the selected week
            //   return shift.startTime.isAfter(selectedDate.subtract(Duration(days: selectedDate.weekday - 1))) &&
            //       shift.startTime.isBefore(selectedDate.add(Duration(days: 7 - selectedDate.weekday)));
            // }).toList();
            print('Week button pressed');
          },
          child: Text('Week'),
        ),
        ElevatedButton(
          onPressed: () {
            // Handle "Month" button press
            print('Month button pressed');
          },
          child: Text('Month'),
        ),
        ElevatedButton(
          onPressed: () {

            print('Year button pressed');
          },
          child: Text('Year'),
        ),
      ],
    );
  }
}
